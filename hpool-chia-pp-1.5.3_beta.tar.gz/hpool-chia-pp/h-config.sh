#!/usr/bin/env bash
firstinstall=$(cat installed)
if [ -z "$firstinstall" ];
then
        apt install -y mhddfs hddtemp
        mkdir /mnt/chia-pp
	mkdir /media
        mkdir /media/chia/pp
fi
echo "1" > installed > /dev/null 2>&1
mkfile_from_symlink $CUSTOM_CONFIG_FILENAME
conf=""
conf+="token: ""\n"
conf+="path:\n"
conf+="- /mnt/chia-pp\n"
conf+="minerName: "
conf+=$HOSTNAME
conf+="\n"

if [[ ! -z $CUSTOM_TEMPLATE ]]; then
	conf+="apiKey: "
	conf+=$CUSTOM_TEMPLATE
	#while read -r line; do
	#	[[ -z $line ]] && continue
	#	conf+=$line
	#done  <<< "$CUSTOM_TEMPLATE"
fi

conf+="\n"
conf+="cachePath: ""\n"
conf+="deviceId: ""\n"
conf+="extraParams: {}\n"
conf+="log:\n"
conf+="  lv: info\n"
conf+="  path: /tmp\n"
conf+="  name: hpool-miner-chiapp\n"
conf+="scanPath: false\n"
conf+="scanMinute: \n"
conf+="debug: ""\n"
conf+="language: cn\n"
conf+="multithreadingLoad: false\n"
conf+="url:\n"
conf+="  info: ""\n"
conf+="  submit: ""\n"
if [[ ! -z $CUSTOM_URL ]]; then
        conf+="  line: $CUSTOM_URL\n"
else
        conf+="  line: ""\n"
fi
conf+="  ws: ""\n"
conf+="  $CUSTOM_USER_CONFIG"
echo -e "$conf" > $CUSTOM_CONFIG_FILENAME
