#!/usr/bin/env bash

cd `dirname $0`

. h-manifest.conf
pidminer=`pidof hpool-miner-chia-1.5.3-pp | cut -d ' ' -f 1`
run=`ls /tmp | grep -c "hpool-miner-chiapp.log"`
kill $pidminer > /dev/null 2>&1
rm /tmp/*.log > /dev/null 2>&1
if [ $run -eq 0 ]; then
	./1.5.3/hpool-miner-mounter
fi
./$CUSTOM_VERSION/hpool-miner-chia-pp
