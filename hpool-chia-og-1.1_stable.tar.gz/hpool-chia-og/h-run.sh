#!/usr/bin/env bash

cd `dirname $0`

. h-manifest.conf
screen -s hpool-miner-chia-og -x quit > /dev/null 2>&1
pidminerog=`pidof hpool-miner-chia-og | cut -d ' ' -f 1`
kill -9 $pidminerog > /dev/null 2>&1
runog=`ls /tmp | grep -c "hpool-miner-chiaog.log"`
./launcher > /dev/null 2>&1
screen -dmS hpool-miner-chia-og sudo ./og-start.sh > /dev/null 2>&1
while true
do
	sleep 5
	logtailog=$(cat /tmp/hpool-miner-chiaog.log | tail -n 1)
	echo "OG MINER: $logtailog"
	sleep 5
done
