#!/usr/bin/env bash
. /hive/miners/custom/hpool-chia-ogpp/h-manifest.conf
amounthddstatsog=$(ls /dev/disk/by-label | grep -c "CHIAOG")
if [ -z "$amounthddstatsog" ]; then
	amounthddstatsog="0"
fi
hddtempstatscountog=1
hddcapacitystatscountog=1
khs=0
ac=0
rj=0
# Stats HDDOG
if [ $amounthddstatsog -eq 0 ]; then
	echo "HDD OG = 0"
else
if [ $amounthddstatsog -gt 1 ]; then
	while [ $hddtempstatscountog -le "$amounthddstatsog" ];
	do
		hddname=$(ls /dev/disk/by-label/ | grep OG | head -n$hddtempstatscountog | tail -n1)
		temphdd=$(hddtemp -n /dev/disk/by-label/$hddname)
		if [[ $temphdd =~ ^[0-9]+$ ]]; then
		if [ $temphdd -gt "$MAX_TEMP_HDD" ]; then
			message danger "HDD($hddname) exceeded $MAX_TEMP_HDD°C, mining stopped"
			message warning "The mining permanently stopped. To start mining again you have to send a command 'miner start'"
            screen -s hpool-miner-chia-og -x quit > /dev/null 2>&1
            pidminerog=`pidof hpool-miner-chia-og | cut -d ' ' -f 1`
            kill -9 $pidminerog > /dev/null 2>&1
            umount /mnt/chia-og
            umount /media/chia/og/*
            hdparm -y /dev/disk/by-label/CHIA*
			miner stop
			break
		fi
		else
			temphdd="null"
		fi
		hddtemparray+="$temphdd "
		let hddtempstatscountog=hddtempstatscountog+1
	done
	khsog=`cat /tmp/hpool-miner-chiaog.log | grep "new mining info" | tail -n 1 | awk '{ print $6 }' | cut -d '"' -f 2`
	if [ -z "$khsog" ] || [ "$khsog" = "0" ]; then
		while [ $hddcapacitystatscountog -le "$amounthddstatsog" ];
			do
				hddcapacityarray+="null "
                let hddcapacitystatscountog=hddcapacitystatscountog+1
			done
	else
		while [ $hddcapacitystatscountog -le "$amounthddstatsog" ];
		do
        		hddcapacitytb=`du -hs /media/chia/og/$hddcapacitystatscountog -B T | cut -d 'T' -f 1`
                hddcapacitytbclean=$(echo "$hddcapacitytb*0.89125" | bc -l )
        		hddcapacityarray+="$hddcapacitytbclean "
        		let hddcapacitystatscountog=hddcapacitystatscountog+1
		done
	fi
else
	hddname=$(ls /dev/disk/by-label/ | grep CHIAOG)
	temphdd=$(hddtemp -n /dev/disk/by-label/$hddname)
        if [ $temphdd -gt "$MAX_TEMP_HDD" ]; then
						message danger "HDD($hddname) exceeded $MAX_TEMP_HDD°C, mining stopped"
						message warning "The mining permanently stopped. To start mining again you have to send a command 'miner start'"
                        screen -s hpool-miner-chia-og -x quit > /dev/null 2>&1
                        pidminerog=`pidof hpool-miner-chia-og | cut -d ' ' -f 1`
                        kill -9 $pidminerog > /dev/null 2>&1
                        umount /mnt/chia-og
                        umount /media/chia/og/*
                        hdparm -y /dev/disk/by-label/CHIA*
						miner stop
			break
        fi

	hddtemparray+="$temphdd"
	khsog=`cat /tmp/hpool-miner-chiaog.log | grep "new mining info" | tail -n 1 | awk '{ print $6 }' | cut -d '"' -f 2`
	if [ -z "$khsog" ] || [ "$khsog" = "0" ]; then
		hddcapacityarray+="null "
	else
		hddcapacitytb=`du -hs /mnt/chia-og -B T | cut -d 'T' -f 1`
        	hddcapacitytbclean=$(echo "$hddcapacitytb*0.89125" | bc -l | awk '{printf("%.2f \n",$1)}')
        	hddcapacityarray+="$hddcapacitytbclean"
	fi
fi
fi
pidminerog=`pidof hpool-miner-chia-og | cut -d ' ' -f 1`
mineruptime=$(ps -p $pidminerog -o etimes | tail -n1 | egrep -o "[0-9].*$")
if [ -z "$khsog" ]; then
	khsog="0"
fi
if [ "$khsog" = "0" ]; then
	acog="0"
	rjog="0"
else
	acog=`cat /tmp/hpool-miner-chiaog.log | grep -c "new mining info"`
	rjog=`cat /tmp/hpool-miner-chiaog.log | grep -c "read message fail"`
fi
khs=$(echo "$khsog")
ac=$(echo "$acog")
rj=$(echo "$rjog")
hddcapacityarrayclean=$(echo ${hddcapacityarray[@]} | tr " " "\n" | jq -cs '.')
hddtemparrayclean=$(echo ${hddtemparray[@]} | tr " " "\n" | jq -cs '.')
hs_units="khs"
ver=`echo $CUSTOM_VERSION`
stats=$(jq -nc \
                                --argjson hs "$hddcapacityarrayclean" \
                                --arg hs_units "$hs_units" \
                                --argjson temp "$hddtemparrayclean" \
                                --arg uptime "$mineruptime" \
				--arg ac "$ac" --arg rj "$rj" \
                                --arg algo "post-og" \
				--arg ver "$ver" \
                                '{$hs, $hs_units, $temp, $uptime, ar: [$ac, $rj], $algo, $ver}')
