cd hpool-chia-og
./hpool-miner-chia-og
