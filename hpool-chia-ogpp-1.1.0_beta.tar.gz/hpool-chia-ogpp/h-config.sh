#!/usr/bin/env bash
apikeyog=""
apikeypp=""
lineog=""
linepp=""
firstinstall=$(cat installed-ogpp)
if [ -z "$firstinstall" ];
then
        apt install -y mhddfs hddtemp hdparm
        mkdir /mnt/chia-og
	mkdir /mnt/chia-pp
        mkdir /media/chia
        mkdir /media/chia/og
	mkdir /media/chia/pp
	echo "1" > installed-ogpp
fi

mkfile_from_symlink $CUSTOM_CONFIG_FILENAME_OG

conf=""
conf+="token: ""\n"
conf+="path:\n"
conf+="- /mnt/chia-og\n"
conf+="minerName: "
conf+=$HOSTNAME
conf+="\n"
apikeyog=$(echo $CUSTOM_TEMPLATE | cut -d '.' -f 1)
if [[ ! -z $apikeyog ]]; then
	conf+="apiKey: "
	conf+=$apikeyog
fi

conf+="\n"
conf+="cachePath: ""\n"
conf+="deviceId: ""\n"
conf+="extraParams: {}\n"
conf+="log:\n"
conf+="  lv: info\n"
conf+="  path: /tmp\n"
conf+="  name: hpool-miner-chiaog\n"
conf+="scanPath: false\n"
conf+="scanMinute: \n"
conf+="debug: ""\n"
conf+="language: cn\n"
conf+="multithreadingLoad: false\n"
conf+="url:\n"
conf+="  info: ""\n"
conf+="  submit: ""\n"

lineog=$(echo $CUSTOM_URL | cut -d '.' -f 1)
if [[ ! -z $lineog ]]; then
        conf+="  line: $lineog\n"
else
        conf+="  line: ""\n"
fi
conf+="  ws: ""\n"
conf+="  $CUSTOM_USER_CONFIG"
echo -e "$conf" > $CUSTOM_CONFIG_FILENAME_OG

# config.yaml for HPOOL MINER CHIA PP

mkfile_from_symlink $CUSTOM_CONFIG_FILENAME_PP

conf=""
conf+="token: ""\n"
conf+="path:\n"
conf+="- /mnt/chia-pp\n"
conf+="minerName: "
conf+=$HOSTNAME
conf+="\n"
apikeypp=$(echo $CUSTOM_TEMPLATE | cut -d '.' -f 2)
if [[ ! -z $apikeypp ]]; then
	conf+="apiKey: "
	conf+=$apikeypp
fi

conf+="\n"
conf+="cachePath: ""\n"
conf+="deviceId: ""\n"
conf+="extraParams: {}\n"
conf+="log:\n"
conf+="  lv: info\n"
conf+="  path: /tmp\n"
conf+="  name: hpool-miner-chiapp\n"
conf+="scanPath: false\n"
conf+="scanMinute: \n"
conf+="debug: ""\n"
conf+="language: cn\n"
conf+="multithreadingLoad: false\n"
conf+="url:\n"
conf+="  info: ""\n"
conf+="  submit: ""\n"

linepp=$(echo $CUSTOM_URL | cut -d '.' -f 2)
if [[ ! -z $linepp ]]; then
        conf+="  line: $linepp\n"
else
        conf+="  line: ""\n"
fi
conf+="  ws: ""\n"
conf+="  $CUSTOM_USER_CONFIG"
echo -e "$conf" > $CUSTOM_CONFIG_FILENAME_PP
