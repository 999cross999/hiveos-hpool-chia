cd hpool-chia-pp
./hpool-miner-chia-pp
