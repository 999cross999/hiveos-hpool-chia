#!/usr/bin/env bash

. h-manifest.conf

amounthddstats=0
hddtempstatscount=0
hddcapacitystatscount=0
hddname=0
hddcapacity=0
hddcapacitytb=0
hddstatshashcount=0
hddstatstempcount=0
khs=0
stats=""
hddtemparray=""
hddcapacityarray=""
hddtemparrayclean=""
hddcapacityarrayclean=""
amounthddstats=$(ls /dev/disk/by-label | grep -c "CHIAOG")
let amounthddstats=amounthddstats-1
if [ $amounthddstats -gt 0 ]; then
	while [ $hddtempstatscount -le "$amounthddstats" ];
	do
        	hddname=$(cat /tmp/hdd$hddtempstatscount-og.tmp)
        	temphdd=$(hddtemp -n /dev/disk/by-label/$hddname)
        	hddtemparray+="$temphdd "
        	let hddtempstatscount=hddtempstatscount+1
	done
	khs=`cat /tmp/hpool-miner-chiaog.log | tail -n 1 | awk '{ print $6 }' | cut -d '"' -f 2`
	if [ -z "$khs" ];
	then
		while [ $hddcapacitystatscount -le "$amounthddstats" ];
        	do
                	hddcapacityarray+="null "
                	let hddcapacitystatscount=hddcapacitystatscount+1
        	done
	else
		while [ $hddcapacitystatscount -le "$amounthddstats" ];
		do
        		hddcapacitytb=`du -hs /media/chia/og/$hddcapacitystatscount | cut -d 'T' -f 1`
                	hddcapacitytbclean=$(echo "$hddcapacitytb*0.99" | bc -l )
        		hddcapacityarray+="$hddcapacitytbclean "
        		let hddcapacitystatscount=hddcapacitystatscount+1
		done
	fi
else
	temphdd=$(hddtemp -n /dev/disk/by-label/CHIAOG*)
	hddtemparray=$(echo $temphdd)
	khs=`cat /tmp/hpool-miner-chiaog.log | tail -n 1 | awk '{ print $6 }' | cut -d '"' -f 2`
	if [ -z "$khs" ];
        then
		hddcapacityarray+="null "
	else
		hddcapacitytb=`du -hs /mnt/chia-og | cut -d 'T' -f 1`
        	hddcapacitytbclean=$(echo "$hddcapacitytb*0.99" | bc -l | awk '{printf("%.2f \n",$1)}')
        	hddcapacityarray=$(echo $hddcapacitytbclean)
	fi
fi
pidminer=`pidof hpool-miner-chia | cut -d ' ' -f 1`
ac=`cat /tmp/hpool-miner-chiaog.log | grep -c "new mining info"`
rj=`cat /tmp/hpool-miner-chiaog.log | grep -c "read message fail"`
mineruptime=$( ps -p $pidminer -o etimes | tail -n1 | egrep -o "[0-9].*$")
hddcapacityarrayclean=$(echo ${hddcapacityarray[@]} | tr " " "\n" | jq -cs '.')
hddtemparrayclean=$(echo ${hddtemparray[@]} | tr " " "\n" | jq -cs '.')
hs_units="TB"
ver=`echo $CUSTOM_VERSION`
stats=$(jq -nc \
                                --argjson hs "$hddcapacityarrayclean" \
                                --arg hs_units "$hs_units" \
                                --argjson temp "$hddtemparrayclean" \
                                --arg uptime "$mineruptime" \
				--arg ac "$ac" --arg rj "$rj" \
                                --arg algo "post-og" \
				--arg ver "$ver" \
                                '{$hs, $hs_units, $temp, $uptime, ar: [$ac, $rj], $algo, $ver}')
